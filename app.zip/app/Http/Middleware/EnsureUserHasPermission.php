<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureUserHasPermission
{
    /**
     * Handle an incoming request.
     *
     * @param  Closure(Request): (Response)  $next
     */
    public function handle(Request $request, Closure $next, string $permission): Response
    {
        $user = $request->user();
        $tieneAlguno = $user !== null
            && collect(explode('|', $permission))->contains(
                fn (string $permiso) => $user->hasPermission($permiso),
            );

        abort_unless($tieneAlguno, Response::HTTP_FORBIDDEN);

        return $next($request);
    }
}
